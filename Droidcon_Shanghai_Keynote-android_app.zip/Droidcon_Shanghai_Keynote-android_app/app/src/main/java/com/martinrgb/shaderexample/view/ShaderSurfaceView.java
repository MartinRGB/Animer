package com.martinrgb.shaderexample.view;


import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.EGLConfig;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.martinrgb.shaderexample.renderer.ShaderRenderer;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLDisplay;


public class ShaderSurfaceView extends GLSurfaceView {
	private ShaderRenderer renderer;

	public ShaderSurfaceView(Context context) {
		super(context);
		setRenderer(context);
	}

	public ShaderSurfaceView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setRenderer(context);
	}
	private void setRenderer(Context context) {
		renderer = new ShaderRenderer(context);
		setEGLContextClientVersion(2);

		setZOrderOnTop(true);
		//setEGLConfigChooser(new MultisampleConfigChooser());
		setEGLConfigChooser(8, 8, 8, 8, 16, 0);
		getHolder().setFormat(PixelFormat.RGBA_8888);
		setRenderer(renderer);
		//setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
		setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

	}

	public ShaderRenderer getRenderer() {
		return renderer;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return true;
	}

	public void setFactorInput(float factor){
		renderer.setFactorInput(factor);
	}

	public void setFactorInput2(float factor){
		renderer.setFactorInput2(factor);
	}




}
