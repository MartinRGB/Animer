package com.martinrgb.shaderexample.renderer.util;

public class LoggerConfig {
    public static final boolean ON = true;
}