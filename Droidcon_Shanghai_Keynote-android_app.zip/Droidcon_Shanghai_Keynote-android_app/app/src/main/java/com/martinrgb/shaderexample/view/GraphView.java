package com.martinrgb.shaderexample.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;

import com.martinrgb.shaderexample.AndroidSpringInterpolator;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class GraphView extends SurfaceView {
    Paint paint = new Paint();

    public GraphView(Context context) {
        super(context);
        paint.setStrokeWidth(5.f);
        paint.setColor(Color.RED);
    }

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(Color.RED);
        paint.setStrokeWidth(5.f);
        this.setBackgroundColor(Color.BLACK);
    }

    @Override
    public void onDraw(Canvas canvas) {

        AndroidSpringInterpolator animator = new AndroidSpringInterpolator(mFactor,mFactor2,5470);
        for (int x=0; x<canvas.getWidth();x++) {
            float size = canvas.getWidth();
            float valueX = x;
            float progress = ((float)valueX/size);
            float valueY = size - (float)animator.getInterpolation(progress)*size;
            float scaleFactor = 0.5f;

            //canvas.drawPoint(valueX *scaleFactor,valueY*scaleFactor + (1-scaleFactor)*size,paint);

            canvas.drawLine(valueX *scaleFactor,
                            valueY*scaleFactor + (1-scaleFactor)*size,
                            (valueX+1)*scaleFactor,
                    (size - (float)animator.getInterpolation( ((float)(valueX+1)/size)   )*size)*scaleFactor + (1-scaleFactor)*size
                            ,paint);
        }
//        float[] mArray = setVertexArray(mFactor,mFactor2);
//        for (int x=0; x<(int)(mArray.length/2.)*canvas.getWidth();x++) {
//            canvas.drawPoint(mArray[x]*canvas.getWidth(),mArray[x*2+1]*canvas.getWidth(),paint);
//        }
    }



    private float[] setVertexArray(float factor,float factor2){
        AndroidSpringInterpolator animator = new AndroidSpringInterpolator(factor,factor2,5470);
        float time = 5.47f;

        float[] animatorArray = new float[(int)(time*60*2)];

        for(int i=0;i< (int)(time*60);i++){
            float timeProgress = ((float)i/time)/60;
            float aniamtorProgress = animator.getInterpolation(timeProgress);
            animatorArray[i*2] = timeProgress;
            animatorArray[i*2+1] = aniamtorProgress;
        }

        return animatorArray;
    }

    private double myFunction(double x){
        return 50 * Math.sin(x / 50) + 100;
    }

    private float mFactor =1500;
    private float mFactor2 = 0.5f;
    public void setFactorInput(float factor){
        mFactor = factor;
        invalidate();
    }

    public void setFactorInput2(float factor){
        mFactor2 = factor;
        invalidate();
    }

}