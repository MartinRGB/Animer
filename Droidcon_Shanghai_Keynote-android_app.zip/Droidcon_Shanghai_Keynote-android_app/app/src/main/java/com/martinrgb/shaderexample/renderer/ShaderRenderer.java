package com.martinrgb.shaderexample.renderer;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.util.Log;

import com.martinrgb.shaderexample.R;
import com.martinrgb.shaderexample.renderer.util.FPSCounter;
import com.martinrgb.shaderexample.renderer.util.LoggerConfig;


import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;


public class ShaderRenderer implements GLSurfaceView.Renderer {

	private final float resolution[] = new float[]{0,0};
	private long startTime;
	private static final float NS_PER_SECOND = 1000000000f;

	private final Context context;

	public ShaderRenderer(Context context) {
		this.context = context;
	}

	private ShaderProgram shaderProgram;

	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		GLES20.glDisable(GLES20.GL_CULL_FACE);
		GLES20.glDisable(GLES20.GL_BLEND);
		GLES20.glDisable(GLES20.GL_DEPTH_TEST);
		GLES20.glClearColor(0f, 0f, 0f, 0f);
		shaderProgram = new ShaderProgram(context,R.raw.simplevert,R.raw.simplefrag);
	}


	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		startTime =  System.nanoTime();
		resolution[0] = width;
		resolution[1] = height;
	}

	@Override
	public void onDrawFrame(GL10 gl) {
		float time = (System.nanoTime() - startTime) / NS_PER_SECOND;
		shaderProgram.setUniformInput(resolution,time,mFactor,mFactor2);

		if(LoggerConfig.ON == true){
			FPSCounter.logFrameRate();
		}
	}

	private float mFactor = 1500;
	public void setFactorInput(float factor){
		mFactor = factor;
	}

	private float mFactor2 = 0.5f;
	public void setFactorInput2(float factor){
		mFactor2 = factor;
	}


}
