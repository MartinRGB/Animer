package com.martinrgb.shaderexample.renderer;

import android.content.Context;
import android.opengl.GLES20;
import android.util.Log;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

import com.martinrgb.shaderexample.AndroidSpringInterpolator;
import com.martinrgb.shaderexample.renderer.util.ShaderHelper;
import com.martinrgb.shaderexample.renderer.util.TextReader;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import static android.opengl.GLES20.GL_LINE_STRIP;

public class ShaderProgram {


    public static final String ATTRIBUTE_POSITION = "a_position";
    public static final String UNIFORM_RESOLUTION = "u_resolution";

    private int program = 0;
    private int positionLoc;
    private int resolutionLoc;
    private static FloatBuffer vertexBuffer;

    float[] vertexArray;

    private float[] toVertexArray(float[] array){

        float[] vertexArray = new float[array.length];

        for (int i =0;i<array.length;i++){

            if(i%2 ==0){
                vertexArray[i] = (array[i]*2 - 1.f)*1.0f*0.5f;
            }
            else{
                vertexArray[i] = (array[i]*2 - 1.f)*1.0f*0.25f;
            }
        }

        return vertexArray;
    }


    public ShaderProgram(Context context, int vert, int frag) {
        if (program != 0) { program = 0; }

        program = ShaderHelper.buildProgram(
                TextReader.readTextFileFromResource(context,vert),
                TextReader.readTextFileFromResource(context,frag));

        init();
    }

    private void init(){

        positionLoc = GLES20.glGetAttribLocation(program, ATTRIBUTE_POSITION);
        resolutionLoc = GLES20.glGetUniformLocation(program, UNIFORM_RESOLUTION);
        setVertexArray(1500,0.5f);
        GLES20.glEnableVertexAttribArray(positionLoc);

    }

    private void setVertexArray(float factor,float factor2){
        AndroidSpringInterpolator animator = new AndroidSpringInterpolator(factor,factor2,5470);
        float time = 5.47f;

        float[] animatorArray = new float[(int)(time*60*2)];

        for(int i=0;i< (int)(time*60);i++){
            float timeProgress = ((float)i/time)/60;
            float aniamtorProgress = animator.getInterpolation(timeProgress);
            animatorArray[i*2] = timeProgress;
            animatorArray[i*2+1] = aniamtorProgress;
        }
        vertexArray = toVertexArray(animatorArray);
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertexArray.length*4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertexArray);
        vertexBuffer.position(0);
    }


    public void setUniformInput(float[] resolution,float time,float factor,float factor2){
        // ##################### clear the canvas #####################
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        setVertexArray(factor,factor2);
        // ##################### first program #####################
        GLES20.glUseProgram(program);
        GLES20.glVertexAttribPointer(positionLoc,2,GLES20.GL_FLOAT, false, 0, vertexBuffer);
        if (resolutionLoc > -1) { GLES20.glUniform2fv(resolutionLoc,1,resolution,0); }
        GLES20.glViewport(0,0,(int) resolution[0],(int) resolution[1]);
        GLES20.glLineWidth(5.f);
        GLES20.glDrawArrays(GL_LINE_STRIP,0,vertexArray.length/2);
    }
}
