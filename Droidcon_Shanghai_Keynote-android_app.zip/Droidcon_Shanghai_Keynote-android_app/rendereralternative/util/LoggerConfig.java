package com.martinrgb.shaderexample.rendereralternative.util;

/**
 * Created by MartinRGB on 2017/2/26.
 */

public class LoggerConfig {
    public static final boolean ON = true;
}