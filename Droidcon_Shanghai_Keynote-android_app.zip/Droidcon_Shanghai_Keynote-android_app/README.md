# Droidcon_Shanghai_Keynote
Android Project I used in Droidcon Shanghai