package com.martinrgb.shaderexample.rendereralternative.util;

/**
 * Created by MartinRGB on 2017/2/26.
 */

public class Constants {
    public static final int BYTES_PER_FLOAT = 4;
}
