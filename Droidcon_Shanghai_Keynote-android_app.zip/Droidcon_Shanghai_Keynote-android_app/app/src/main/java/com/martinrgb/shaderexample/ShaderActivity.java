package com.martinrgb.shaderexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.martinrgb.shaderexample.seekbar.BubbleSeekBar;
import com.martinrgb.shaderexample.view.GraphView;


public class ShaderActivity extends AppCompatActivity {

    //private ShaderSurfaceView shaderSurfaceView;
    private GraphView graphView;
    private final String TAG = "ShaderActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // # delete Title Bar
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // # delete Action Bar
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_shader);

        initShaderView();
        setRangeSeekbar();
    }

    private void initShaderView() {
        //shaderSurfaceView = findViewById(R.id.shader_surfaceview);
        graphView = findViewById(R.id.graph_view);
    }

    private BubbleSeekBar mSeek,mSeek2;
    private void setRangeSeekbar(){
        mSeek = findViewById(R.id.bs_1);
        mSeek2 = findViewById(R.id.bs_2);

        mSeek.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                //Log.e("progressFloat",String.valueOf(progressFloat));
                //shaderSurfaceView.setFactorInput(progressFloat);
                graphView.setFactorInput(progressFloat);
            }

            @Override
            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat) {

            }
            @Override
            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });

        mSeek2.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                //shaderSurfaceView.setFactorInput2(progressFloat);
                graphView.setFactorInput2(progressFloat);
            }

            @Override
            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat) {

            }
            @Override
            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });

    }

    private boolean isClosed = false;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)){
            if(!isClosed){
                findViewById(R.id.borad).setVisibility(View.INVISIBLE);
            }
            else{
                findViewById(R.id.borad).setVisibility(View.VISIBLE);
            }
            isClosed = !isClosed;
        }
        return true;
    }

}
